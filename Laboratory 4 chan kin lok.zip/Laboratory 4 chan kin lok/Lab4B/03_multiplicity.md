# Multiplicity Assignment: EcoCampus IoT Dashboard (Lab 4B)

| Class A | Mult A | Relationship | Mult B | Class B | Reading |
|---|---|---|---|---|---|
| Hall | 1 | contains | 1..* | Sensor | One hall contains 1 to many sensors |
| Sensor | 1 | produces | 0..* | EnergyReading | One sensor produces 0 to many readings |
| Hall | 1 | has | 1 | AlertThreshold | One hall has exactly 1 threshold config |
| Hall | 1 | raises | 0..* | EnergyAlert | One hall raises 0 to many alerts |
| EnergyAlert | 1 | triggers | 1..2 | Notification | One alert triggers 1 to 2 notifications (email + SMS) |
| AlertThreshold | 1 | logs | 0..* | AuditEntry | One threshold logs 0 to many audit entries |
| User | 1 | creates | 0..* | AuditEntry | One user creates 0 to many audit entries |
| MonthlyReport | 1 | aggregates | 1..* | Hall | One report aggregates data from 1 to many halls |
| Hall | 1 | has | 0..* | BookingRecord | One hall has 0 to many bookings |
| EnergyAlert | * | triggered by | 1 | AlertThreshold | Many alerts triggered by one threshold |

---

## Multiplicity Logic Validation Checklist

- [x] **Does the multiplicity at each end make business sense?** (Yes, e.g., an alert dispatches 1 to 2 notifications via Email/SMS).
- [x] **Are there any `0..*` that should be `1..*` (mandatory)?** (Yes, Hall must have at least `1..*` Sensor and MonthlyReport must aggregate `1..*` Halls).
- [x] **Are there any `1` that should be `0..1` (optional)?** (Verified; AlertThreshold to Hall is mandatory 1-to-1).
