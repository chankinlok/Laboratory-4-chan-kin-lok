# Class Internals: EcoCampus IoT Dashboard (Lab 4B)

## 1. Class Attributes Definition

### Class: User
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | userId | String | Unique identifier (FR-09) |
| `+` | fullName | String | Display name |
| `+` | email | String | Notification target |
| `+` | role | UserRole | Enum: OFFICER, MANAGER, ADMIN |
| `-` | isAuthenticated | boolean | Session state |

---

### Class: Hall
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | hallId | String | Unique identifier |
| `+` | name | String | Display name (e.g., "Hall A") |
| `+` | location | String | Building / floor reference |
| `+` | capacity | int | Seating capacity |
| `+` | isOccupied | boolean | Derived from BookingRecord (FR-07) |

---

### Class: Sensor
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | sensorId | String | Unique hardware identifier |
| `+` | type | SensorType | Enum: POWER, TEMPERATURE |
| `+` | installationDate | DateTime | Maintenance tracking |
| `+` | status | SensorStatus | Enum: ONLINE, OFFLINE, FAULT |
| `+` | lastReadingTime | DateTime | Health monitoring |

---

### Class: EnergyReading
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | readingId | String | Unique identifier |
| `+` | timestamp | DateTime | When reading was taken |
| `+` | consumptionValue | double | Energy in kWh |
| `+` | unit | String | Measurement unit |

---

### Class: AlertThreshold
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | thresholdId | String | Unique identifier |
| `+` | value | double | Threshold limit (kWh) |
| `+` | baseline | double | Historical average |
| `+` | isActive | boolean | Whether alerting is enabled |
| `+` | lastModified | DateTime | Audit tracking (FR-08) |
| `+` | modifiedBy | String | User who changed it |

---

### Class: EnergyAlert
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | alertId | String | Unique identifier |
| `+` | triggeredAt | DateTime | When alert was raised |
| `+` | consumptionAtTrigger | double | Value that breached threshold |
| `+` | status | AlertStatus | Enum: ACTIVE, ACKNOWLEDGED, RESOLVED |
| `+` | acknowledgedBy | String | User who acknowledged |
| `+` | resolvedAt | DateTime | When resolved |
| `+` | resolutionNotes | String | Description of fix |

---

### Class: Notification
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | notificationId | String | Unique identifier |
| `+` | channel | NotificationChannel | Enum: EMAIL, SMS |
| `+` | recipientAddress | String | Email or phone number |
| `+` | message | String | Alert content |
| `+` | sentAt | DateTime | Dispatch timestamp |
| `+` | deliveryStatus | DeliveryStatus | Enum: PENDING, SENT, FAILED |

---

### Class: MonthlyReport
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | reportId | String | Unique identifier |
| `+` | period | String | e.g., "2026-09" |
| `+` | generatedAt | DateTime | Creation timestamp |
| `+` | totalConsumption | double | Aggregate kWh |
| `+` | peakUsage | double | Maximum recorded |
| `+` | costEstimate | double | Financial estimate |
| `+` | filePath | String | Storage location of PDF |

---

### Class: AuditEntry
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | entryId | String | Unique identifier |
| `+` | timestamp | DateTime | When change occurred |
| `+` | performedBy | String | User ID |
| `+` | action | String | What was changed |
| `+` | oldValue | String | Previous value |
| `+` | newValue | String | New value |

---

### Class: BookingRecord
| Visibility | Attribute | Data Type | Source / Justification |
|---|---|---|---|
| `-` | bookingId | String | Unique identifier |
| `+` | startTime | DateTime | Booking start |
| `+` | endTime | DateTime | Booking end |
| `+` | bookedBy | String | Who made the booking |
| `+` | purpose | String | Event description |

---

## 2. Class Operations Definition

### Class: User
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | authenticate(credentials) | credentials: String | boolean | FR-09: SSO login |
| `+` | getRole() | - | UserRole | Role-based access |
| `+` | configureThreshold(hallId, value) | hallId: String, value: double | boolean | FR-06 |

### Class: Hall
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | getCurrentOccupancy() | - | boolean | FR-07 |
| `+` | getActiveAlerts() | - | List\<EnergyAlert\> | FR-05 |
| `+` | getTotalConsumption(period) | period: String | double | FR-02 |

### Class: Sensor
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | takeReading() | - | EnergyReading | FR-01 |
| `+` | getStatus() | - | SensorStatus | UC-11 |
| `+` | reportFault() | - | void | UC-11 |

### Class: EnergyReading
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | getValue() | - | double | Data access |
| `+` | getTimestamp() | - | DateTime | Data access |

### Class: AlertThreshold
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | setValue(newValue) | newValue: double | boolean | FR-06 |
| `+` | validateInput(value) | value: double | boolean | UC-05 Step 6 |
| `+` | checkDeviation(newValue) | newValue: double | double | UC-05 Step 7 |
| `+` | logChange(oldVal, newVal, userId) | oldVal: double, newVal: double, userId: String | void | FR-08 |

### Class: EnergyAlert
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | acknowledge(userId) | userId: String | void | UC-06 Step 3 |
| `+` | resolve(notes) | notes: String | void | UC-06 Step 6 |
| `+` | escalate(reason) | reason: String | void | UC-06 Extension |
| `+` | getStatus() | - | AlertStatus | Status tracking |

### Class: Notification
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | dispatch() | - | boolean | FR-05 |
| `+` | getDeliveryStatus() | - | DeliveryStatus | Tracking |

### Class: MonthlyReport
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | generate() | - | boolean | FR-04 |
| `+` | calculateMetrics() | - | void | FR-04 |
| `+` | exportToPDF() | - | String | FR-04 |
| `+` | distribute(recipients) | recipients: List\<String\> | void | FR-04 |

### Class: AuditEntry
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | getDetails() | - | String | FR-08 |

### Class: BookingRecord
| Visibility | Operation | Parameters | Return Type | Justification |
|---|---|---|---|---|
| `+` | isCurrentlyActive() | - | boolean | FR-07 |
| `+` | overlapsWith(dateTime) | dateTime: DateTime | boolean | Occupancy check |
