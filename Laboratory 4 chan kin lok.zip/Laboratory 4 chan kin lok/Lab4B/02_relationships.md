# Relationship Identification & Justification (Lab 4B)

## 1. Relationship Identification

| Class A | Class B | Relationship Type | Rationale | Direction |
|---|---|---|---|---|
| Hall | Sensor | Composition | Sensors are installed in and belong to a specific hall; if hall is decommissioned, sensors are removed | Hall `*--` Sensor |
| Sensor | EnergyReading | Composition | Readings are produced by and belong to a specific sensor; meaningless without the sensor | Sensor `*--` EnergyReading |
| Hall | AlertThreshold | Composition | Thresholds are configured per hall; cannot exist without a hall | Hall `*--` AlertThreshold |
| Hall | EnergyAlert | Association | Alerts are raised for a hall but can exist independently for reporting | Hall `--` EnergyAlert |
| EnergyAlert | Notification | Composition | Notifications are created for and belong to a specific alert | EnergyAlert `*--` Notification |
| AlertThreshold | AuditEntry | Composition | Audit entries log threshold changes; tied to the threshold | AlertThreshold `*--` AuditEntry |
| User | AuditEntry | Association | Users create audit entries but entries reference users | User `--` AuditEntry |
| User | AlertThreshold | Dependency | User temporarily uses threshold during configuration | User `..>` AlertThreshold |
| MonthlyReport | Hall | Association | Report aggregates data from halls | MonthlyReport `--` Hall |
| MonthlyReport | EnergyReading | Dependency | Report temporarily reads energy data | MonthlyReport `..>` EnergyReading |
| Hall | BookingRecord | Association | Bookings reference halls | Hall `--` BookingRecord |
| EnergyAlert | AlertThreshold | Association | Alert is triggered by a threshold | EnergyAlert `--` AlertThreshold |

---

## 2. Composition vs. Aggregation Decisions

| Relationship | Can Part Exist Alone? | Created/Destroyed Together? | Shared? | Verdict |
|---|---|---|---|---|
| **Hall → Sensor** | No (sensor is installed in specific hall) | Yes | No | **Composition** |
| **Sensor → EnergyReading** | No (reading is meaningless without sensor) | Yes | No | **Composition** |
| **Hall → AlertThreshold** | No (threshold is per-hall configuration) | Yes | No | **Composition** |
| **EnergyAlert → Notification** | No (notification is for specific alert) | Yes | No | **Composition** |
| **AlertThreshold → AuditEntry** | No (audit entry logs specific threshold change) | Yes | No | **Composition** |
