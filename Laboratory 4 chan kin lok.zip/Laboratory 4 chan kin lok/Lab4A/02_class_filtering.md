# Candidate Class Filtering: EcoCampus IoT Dashboard (Lab 4A)

| # | NOUN / NOUN PHRASE | DECISION | RATIONALE | RESULTING CLASS / ATTRIBUTE |
|---|---|---|---|---|
| 1 | Facilities Manager | KEEP | Human actor with distinct responsibilities | `User` (role) |
| 2 | threshold configuration screen | DISCARD | UI element, not domain entity | - |
| 3 | System | DISCARD | Too vague; represents system boundary | - |
| 4 | thresholds | KEEP → MERGE | Core domain object; merge with "threshold settings" | `AlertThreshold` |
| 5 | monitored halls | KEEP | Physical entity the system tracks | `Hall` |
| 6 | hall | MERGE | Same as "monitored halls" | `Hall` |
| 7 | threshold settings | MERGE | Same as AlertThreshold "thresholds" | `AlertThreshold` |
| 8 | historical consumption context | ATTRIBUTE | Descriptive data about consumption | `Hall.historicalData` |
| 9 | threshold value | ATTRIBUTE | Property of AlertThreshold | `AlertThreshold.value` |
| 10 | input | DISCARD | Too generic; UI interaction detail | - |
| 11 | deviation | ATTRIBUTE | Calculated property | `AlertThreshold.deviation` |
| 12 | historical baseline | ATTRIBUTE | Reference data for threshold | `AlertThreshold.baseline` |
| 13 | confirmation summary | DISCARD | UI output, not domain entity | - |
| 14 | projected alert frequency | ATTRIBUTE | Computed property | `AlertThreshold.projectedFrequency` |
| 15 | change | DISCARD | Action, not entity | - |
| 16 | audit trail | KEEP | Domain object tracking changes | `AuditEntry` |
| 17 | success confirmation | DISCARD | UI feedback | - |
| 18 | Alert engine | DISCARD | System component, not domain entity | - |
| 19 | IoT Sensor Network | KEEP → MERGE | Merge with "sensor" | `Sensor` |
| 20 | consumption data | KEEP | Core measurement data | `EnergyReading` |
| 21 | sensor data | MERGE | Same as "consumption data" | `EnergyReading` |
| 22 | sensor status | ATTRIBUTE | Property of Sensor | `Sensor.status` |
| 23 | sensor | KEEP | Physical device entity | `Sensor` |
| 24 | booking system | DISCARD | External system (actor, not internal class) | - |
| 25 | occupancy | ATTRIBUTE | State derived from booking | `Hall.isOccupied` |
| 26 | hall | MERGE | Already identified | `Hall` |
| 27 | consumption | MERGE | Same as "consumption data" | `EnergyReading` |
| 28 | threshold | MERGE | Already identified | `AlertThreshold` |
| 29 | alert record | KEEP | Core domain object | `EnergyAlert` |
| 30 | email notification | KEEP → MERGE | Merge with SMS notification | `Notification` |
| 31 | SMS notification | MERGE | Same as "email notification" (different channel) | `Notification` |
| 32 | dashboard alert widget | DISCARD | UI component, not domain entity | - |
| 33 | Scheduler | DISCARD | Temporal actor, not domain entity | - |
| 34 | monthly report | KEEP | Domain object produced by system | `MonthlyReport` |
| 35 | consumption data | MERGE | Already identified | `EnergyReading` |
| 36 | previous month | ATTRIBUTE | Time parameter | `MonthlyReport.period` |
| 37 | key metrics | ATTRIBUTE | Computed properties of report | `MonthlyReport.metrics` |
| 38 | monitored hall | MERGE | Already identified | `Hall` |
| 39 | hall-specific statistics | ATTRIBUTE | Data within report | `MonthlyReport.hallStatistics` |
| 40 | comparative analysis | ATTRIBUTE | Section of report | `MonthlyReport.comparison` |
| 41 | report | MERGE | Same as "monthly report" | `MonthlyReport` |
| 42 | PDF | DISCARD | Output format, not domain entity | - |
| 43 | stakeholders | DISCARD | Generic term; covered by User | - |

---

## Final Candidate Class List (10 Validated Classes)

| # | CLASS NAME | SOURCE NOUNS | JUSTIFICATION |
|---|---|---|---|
| 1 | **User** | Facilities Manager, IT Administrator, Sustainability Officer | Human actors who interact with system |
| 2 | **Hall** | monitored halls, hall | Physical entity being monitored |
| 3 | **Sensor** | IoT Sensor Network, sensor | Hardware device collecting data |
| 4 | **EnergyReading** | consumption data, sensor data | Measurement data produced by sensors |
| 5 | **AlertThreshold** | thresholds, threshold settings | Configurable limit per hall |
| 6 | **EnergyAlert** | alert record | Event triggered by threshold breach |
| 7 | **Notification** | email notification, SMS notification | Message dispatched to users |
| 8 | **MonthlyReport** | monthly report, report | Aggregated output document |
| 9 | **AuditEntry** | audit trail | Log of system changes |
| 10 | **BookingRecord** | occupancy, booking | External data indicating hall usage |
