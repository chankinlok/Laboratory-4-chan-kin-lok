# Noun Analysis: EcoCampus IoT Dashboard (Lab 4A)

## 1. Noun Extraction from UC-05: Configure Alert Thresholds

### Source Text (UC-05 Main Success Scenario)
> "Facilities Manager requests threshold configuration screen. System displays current thresholds for all monitored halls. Facilities Manager selects a specific hall. System displays hall-specific threshold settings and historical consumption context. Facilities Manager enters new threshold value. System validates the input. System checks deviation against historical baseline. System displays confirmation summary with projected alert frequency. Facilities Manager confirms the change. System saves the new threshold. System logs the change in the audit trail. System displays success confirmation. Alert engine begins using the new threshold immediately."

### Extracted Nouns / Noun Phrases:
1. Facilities Manager
2. threshold configuration screen
3. System
4. thresholds
5. monitored halls
6. specific hall
7. threshold settings
8. historical consumption context
9. new threshold value
10. input
11. deviation
12. historical baseline
13. confirmation summary
14. projected alert frequency
15. change
16. new threshold
17. audit trail
18. success confirmation
19. Alert engine

---

## 2. Noun Extraction from UC-10: Detect Anomalous Consumption

### Source Text (UC-10 Main Success Scenario)
> "IoT Sensor Network streams consumption data. System receives sensor data. System checks sensor status. If sensor is online, system queries booking system for occupancy. System determines if hall is occupied. If hall is unoccupied and consumption exceeds threshold, system generates alert record. System dispatches email and SMS notification. System updates dashboard alert widget."

### Extracted Nouns / Noun Phrases:
1. IoT Sensor Network
2. consumption data
3. System
4. sensor data
5. sensor status
6. sensor
7. booking system
8. occupancy
9. hall
10. threshold
11. alert record
12. email notification
13. SMS notification
14. dashboard alert widget

---

## 3. Noun Extraction from UC-04: Generate Monthly Report

### Source Text (UC-04 Main Success Scenario)
> "Scheduler triggers monthly report generation. System aggregates consumption data for previous month. System calculates key metrics for each monitored hall. System computes hall-specific statistics. System generates comparative analysis. System formats report as PDF. System distributes report to stakeholders. System archives report."

### Extracted Nouns / Noun Phrases:
1. Scheduler
2. monthly report generation
3. System
4. consumption data
5. previous month
6. key metrics
7. monitored hall
8. hall-specific statistics
9. comparative analysis
10. report
11. PDF
12. stakeholders
