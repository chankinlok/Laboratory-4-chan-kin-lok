# CRC Cards: EcoCampus IoT Dashboard (Lab 4A)

### Class: Hall
| Responsibilities | Collaborators |
|---|---|
| Know its name, location, and capacity | Sensor |
| Know its current occupancy status | BookingRecord |
| Track its assigned sensors | AlertThreshold |
| Store its configured thresholds | EnergyAlert |
| Report its energy consumption | MonthlyReport |

---

### Class: Sensor
| Responsibilities | Collaborators |
|---|---|
| Know its ID, type, and installation location | Hall |
| Report its operational status (online/offline) | EnergyReading |
| Produce energy readings at regular intervals | |
| Detect and report faults | |

---

### Class: EnergyReading
| Responsibilities | Collaborators |
|---|---|
| Store timestamp and consumption value | Sensor |
| Associate with a specific sensor | Hall |
| Support aggregation for reporting | MonthlyReport |

---

### Class: AlertThreshold
| Responsibilities | Collaborators |
|---|---|
| Store threshold value for a specific hall | Hall |
| Track historical baseline | AuditEntry |
| Validate new threshold values | User |
| Trigger alerts when breached | EnergyAlert |

---

### Class: EnergyAlert
| Responsibilities | Collaborators |
|---|---|
| Record alert details (time, hall, value) | Hall |
| Track alert status (Active/Acknowledged/Resolved) | AlertThreshold |
| Trigger notifications | Notification |
| Log resolution actions | AuditEntry |

---

### Class: Notification
| Responsibilities | Collaborators |
|---|---|
| Compose alert message | EnergyAlert |
| Select delivery channel (email/SMS) | User |
| Dispatch message to recipient | |
| Track delivery status | |

---

### Class: MonthlyReport
| Responsibilities | Collaborators |
|---|---|
| Aggregate consumption data for a period | EnergyReading |
| Calculate per-hall statistics | Hall |
| Generate comparative analysis | User |
| Produce downloadable output | |

---

### Class: AuditEntry
| Responsibilities | Collaborators |
|---|---|
| Record who made a change and when | User |
| Store old and new values | AlertThreshold |
| Support compliance reporting | EnergyAlert |

---

### Class: User
| Responsibilities | Collaborators |
|---|---|
| Authenticate via university SSO | AuditEntry |
| Know its role (Officer/Manager/Admin) | Notification |
| Access authorised functions | AlertThreshold |
| Configure system settings | |

---

### Class: BookingRecord
| Responsibilities | Collaborators |
|---|---|
| Store booking time slot and hall reference | Hall |
| Indicate whether hall is occupied | |
| Support occupancy determination | |

---

## CRC Card Validation Checklist

- [x] **Does each class have at least 2 responsibilities?** (Yes, all classes have 2 to 5 distinct responsibilities).
- [x] **Does each class have at least 1 collaborator?** (Yes, all classes collaborate with at least 1 other domain entity).
- [x] **Are responsibilities specific (not vague)?** (Yes, each action/attribute is concrete).
- [x] **Are collaborators limited to other identified classes?** (Yes, only valid domain classes are listed as collaborators).
