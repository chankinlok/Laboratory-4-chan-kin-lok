# Design Principle Validation: EcoCampus Class Diagram (Lab 4C)

## 1. SOLID Principles Evaluation

### Single Responsibility Principle (SRP)
Each class has one clear, single purpose in the domain model:
- **User**: Authentication and role management (does not handle alert logic).
- **Hall**: Represents physical space and occupancy (delegates sensing to Sensor).
- **Sensor**: Data collection and hardware status (does not interpret readings).
- **EnergyReading**: Stores individual measurement values (pure data holder).
- **AlertThreshold**: Configures and validates limits (delegates alert creation to EnergyAlert).
- **EnergyAlert**: Tracks alert lifecycle (delegates messaging to Notification).
- **Notification**: Message composition and dispatch.
- **MonthlyReport**: Aggregates and formats output (reads data, does not modify it).
- **AuditEntry**: Records change history (passive compliance log).
- **BookingRecord**: Represents external occupancy data (read-only reference).

### Open/Closed Principle (OCP)
- **Can new sensor types be added without modifying Sensor class?** Yes (extend `SensorType` enum).
- **Can new notification channels be added without modifying Notification class?** Yes (extend `NotificationChannel` enum).
- **Can new alert statuses be added without modifying EnergyAlert class?** Yes (extend `AlertStatus` enum).

### Dependency Inversion Principle (DIP)
- **Does MonthlyReport depend on abstractions or concretions?** Depends on `EnergyReading` directly (acceptable for Phase 1 conceptual/domain modeling).
- **Does User depend on AlertThreshold directly?** Uses dependency (`..>`); acceptable temporary interaction during configuration.

---

## 2. Common Modelling Mistakes Checklist

| Mistake | Checked? | Status |
|---|---|---|
| 1. Verb as class name | [x] Passed | All class names are Nouns |
| 2. Attribute as class | [x] Passed | Attributes properly assigned |
| 3. Missing multiplicity | [x] Passed | All ends have explicit multiplicity |
| 4. Over-inheritance (>3 levels) | [x] Passed | Flat hierarchy, composition over inheritance |
| 5. Circular dependency | [x] Passed | Directed flow, no circular dependency loops |
| 6. Implementation leaking | [x] Passed | Domain level abstraction used |
| 7. God class (>15 operations) | [x] Passed | Max operations per class is 7 (`EnergyAlert`) |

---

## 3. Class Metric Summary

| Class Name | Attributes Count | Operations Count | Relationships Count | Complexity Rating |
|---|---|---|---|---|
| **User** | 5 | 3 | 3 | Low |
| **Hall** | 5 | 3 | 5 | Medium |
| **Sensor** | 5 | 3 | 2 | Low |
| **EnergyReading** | 4 | 2 | 2 | Low |
| **AlertThreshold** | 4 | 6 | 4 | Medium |
| **EnergyAlert** | 4 | 7 | 4 | Medium |
| **Notification** | 6 | 2 | 2 | Low |
| **MonthlyReport** | 7 | 4 | 3 | Medium |
| **AuditEntry** | 6 | 1 | 3 | Low |
| **BookingRecord** | 5 | 2 | 2 | Low |

- **Average attributes per class**: 5.6
- **Average operations per class**: 2.8
- **Assessment**: Well-balanced design; no class is overly complex or under-specified.
