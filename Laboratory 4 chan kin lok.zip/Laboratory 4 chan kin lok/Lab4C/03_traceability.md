# Traceability Integration: EcoCampus IoT Dashboard (Lab 4C)

## 1. Use Case to Class Mapping

| UC ID | Use Case | Classes Involved | Key Operations |
|---|---|---|---|
| **UC-01** | View Real-Time Dashboard | Hall, Sensor, EnergyReading | `Sensor.takeReading()`, `Hall.getTotalConsumption()` |
| **UC-04** | Generate Monthly Report | MonthlyReport, Hall, EnergyReading | `MonthlyReport.generate()`, `MonthlyReport.calculateMetrics()` |
| **UC-05** | Configure Alert Thresholds | Hall, AlertThreshold, User, AuditEntry | `AlertThreshold.setValue()`, `AlertThreshold.validateInput()` |
| **UC-06** | Respond to Energy Alert | EnergyAlert, Notification, User | `EnergyAlert.acknowledge()`, `EnergyAlert.resolve()` |
| **UC-10** | Detect Anomalous Consumption | Sensor, EnergyReading, AlertThreshold, EnergyAlert, BookingRecord | `AlertThreshold.checkDeviation()`, `EnergyAlert` creation |

---

## 2. Operation Coverage Check

| UC Step | Narrative Action | Class.Operation | Covered? |
|---|---|---|---|
| **UC-05 Step 5** | Enters new threshold value | `AlertThreshold.setValue()` | [x] Yes |
| **UC-05 Step 6** | System validates input | `AlertThreshold.validateInput()` | [x] Yes |
| **UC-05 Step 7** | Checks deviation | `AlertThreshold.checkDeviation()` | [x] Yes |
| **UC-05 Step 11**| Logs change in audit trail | `AlertThreshold.logChange()` | [x] Yes |
| **UC-06 Step 3** | Acknowledges alert | `EnergyAlert.acknowledge()` | [x] Yes |
| **UC-06 Step 6** | Confirms resolution | `EnergyAlert.resolve()` | [x] Yes |
| **UC-10 Step 4** | Queries booking system | `BookingRecord.isCurrentlyActive()` | [x] Yes |
| **UC-10 Step 7** | Generates alert record | `EnergyAlert` (constructor) | [x] Yes |
| **UC-10 Step 8** | Dispatches notification | `Notification.dispatch()` | [x] Yes |
| **UC-04 Step 2** | Aggregates consumption data | `MonthlyReport.calculateMetrics()` | [x] Yes |
