# Enumeration Classes: EcoCampus IoT Dashboard (Lab 4C)

## 1. Enumeration Definitions

| Enumeration | Values | Used By |
|---|---|---|
| **UserRole** | OFFICER, FACILITIES_MANAGER, IT_ADMIN | `User.role` |
| **SensorType** | POWER, TEMPERATURE, HUMIDITY | `Sensor.type` |
| **SensorStatus** | ONLINE, OFFLINE, FAULT | `Sensor.status` |
| **AlertStatus** | ACTIVE, ACKNOWLEDGED, RESOLVED, ESCALATED | `EnergyAlert.status` |
| **NotificationChannel** | EMAIL, SMS | `Notification.channel` |
| **DeliveryStatus** | PENDING, SENT, DELIVERED, FAILED | `Notification.deliveryStatus` |

---

## 2. Enumeration Usage Verification

- [x] **UserRole** $ightarrow$ `User.role`
- [x] **SensorType** $ightarrow$ `Sensor.type`
- [x] **SensorStatus** $ightarrow$ `Sensor.status`
- [x] **AlertStatus** $ightarrow$ `EnergyAlert.status`
- [x] **NotificationChannel** $ightarrow$ `Notification.channel`
- [x] **DeliveryStatus** $ightarrow$ `Notification.deliveryStatus`
