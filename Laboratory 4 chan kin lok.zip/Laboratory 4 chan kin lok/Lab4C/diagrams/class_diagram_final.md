# Complete Production Class Diagram: EcoCampus IoT Dashboard (Lab 4C)

```mermaid
classDiagram
    %% Enumerations
    class UserRole {
        <<enumeration>>
        OFFICER
        FACILITIES_MANAGER
        IT_ADMIN
    }

    class SensorType {
        <<enumeration>>
        POWER
        TEMPERATURE
        HUMIDITY
    }

    class SensorStatus {
        <<enumeration>>
        ONLINE
        OFFLINE
        FAULT
    }

    class AlertStatus {
        <<enumeration>>
        ACTIVE
        ACKNOWLEDGED
        RESOLVED
        ESCALATED
    }

    class NotificationChannel {
        <<enumeration>>
        EMAIL
        SMS
    }

    class DeliveryStatus {
        <<enumeration>>
        PENDING
        SENT
        DELIVERED
        FAILED
    }

    %% Core Classes
    class User {
        -String userId
        +String fullName
        +String email
        +UserRole role
        -boolean isAuthenticated
        +authenticate(credentials) boolean
        +getRole() UserRole
        +configureThreshold(hallId, value) boolean
    }

    class Hall {
        -String hallId
        +String name
        +String location
        +int capacity
        +boolean isOccupied
        +getCurrentOccupancy() boolean
        +getActiveAlerts() List~EnergyAlert~
        +getTotalConsumption(period) double
    }

    class Sensor {
        -String sensorId
        +SensorType type
        +DateTime installationDate
        +SensorStatus status
        +DateTime lastReadingTime
        +takeReading() EnergyReading
        +getStatus() SensorStatus
        +reportFault() void
    }

    class EnergyReading {
        -String readingId
        +DateTime timestamp
        +double consumptionValue
        +String unit
        +getValue() double
        +getTimestamp() DateTime
    }

    class AlertThreshold {
        -String thresholdId
        +double value
        +double baseline
        +boolean isActive
        +DateTime lastModified
        +String modifiedBy
        +setValue(newValue) boolean
        +validateInput(value) boolean
        +checkDeviation(newValue) double
        +logChange(oldVal, newVal, userId) void
    }

    class EnergyAlert {
        -String alertId
        +DateTime triggeredAt
        +double consumptionAtTrigger
        +AlertStatus status
        +String acknowledgedBy
        +DateTime resolvedAt
        +String resolutionNotes
        +acknowledge(userId) void
        +resolve(notes) void
        +escalate(reason) void
        +getStatus() AlertStatus
    }

    class Notification {
        -String notificationId
        +NotificationChannel channel
        +String recipientAddress
        +String message
        +DateTime sentAt
        +DeliveryStatus deliveryStatus
        +dispatch() boolean
        +getDeliveryStatus() DeliveryStatus
    }

    class MonthlyReport {
        -String reportId
        +String period
        +DateTime generatedAt
        +double totalConsumption
        +double peakUsage
        +double costEstimate
        +String filePath
        +generate() boolean
        +calculateMetrics() void
        +exportToPDF() String
        +distribute(recipients) void
    }

    class AuditEntry {
        -String entryId
        +DateTime timestamp
        +String performedBy
        +String action
        +String oldValue
        +String newValue
        +getDetails() String
    }

    class BookingRecord {
        -String bookingId
        +DateTime startTime
        +DateTime endTime
        +String bookedBy
        +String purpose
        +isCurrentlyActive() boolean
        +overlapsWith(dateTime) boolean
    }

    %% Core Domain Relationships
    Hall "1" *-- "1..*" Sensor : contains
    Sensor "1" *-- "0..*" EnergyReading : produces
    Hall "1" *-- "1" AlertThreshold : has
    Hall "1" -- "0..*" EnergyAlert : raises
    EnergyAlert "1" *-- "1..2" Notification : triggers
    AlertThreshold "1" *-- "0..*" AuditEntry : logs
    User "1" -- "0..*" AuditEntry : creates
    User ..> AlertThreshold : configures
    MonthlyReport "1" -- "1..*" Hall : aggregates
    MonthlyReport ..> EnergyReading : reads
    Hall "1" -- "0..*" BookingRecord : has
    EnergyAlert "*" -- "1" AlertThreshold : triggered by

    %% Enumeration Dependency Dependencies
    UserRole ..> User
    SensorType ..> Sensor
    SensorStatus ..> Sensor
    AlertStatus ..> EnergyAlert
    NotificationChannel ..> Notification
    DeliveryStatus ..> Notification
```
